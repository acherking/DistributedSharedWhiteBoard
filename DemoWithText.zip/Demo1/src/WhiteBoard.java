public class WhiteBoard {
    private String ipaddress;
    private int port;
    private String manager;
    private String[] drawer;
    private String communication;
    public String getIpaddress(){
        return ipaddress;
    }
    public int getPort(){
        return port;
    }
    public String getManager(){
        return manager;
    }
    public String[] getDrawer(){
        return drawer;
    }
    public String getCommunication(){
        return communication;
    }
    public void setIpaddress(String ipaddress){
        this.ipaddress=ipaddress;
    }
    public void setPort(int port){
        this.port=port;
    }
    public void setManager(String manager){
        this.manager=manager;
    }
    public void setDrawer(String[] drawer){
        this.drawer=drawer;
    }
    public void setCommunication(String communication){
        this.communication=communication;
    }
}
