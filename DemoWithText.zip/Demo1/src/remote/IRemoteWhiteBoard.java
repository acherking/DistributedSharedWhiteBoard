package remote;
import java.awt.*;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IRemoteWhiteBoard extends Remote {

    public void painting(String name, MyShape temperShape) throws RemoteException;

    public void painted(String name, MyShape durableShape) throws RemoteException;
}
