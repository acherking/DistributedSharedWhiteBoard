
import java.awt.BasicStroke;
import java.awt.Canvas;
import java.awt.Color; 
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener; 
import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JPanel; 
public class DrawListener extends Canvas implements ActionListener, MouseListener, MouseMotionListener {	
	private int x1, x2, y1, y2;	
	private String Shape = "Line";	
	static Color color=Color.black;	
	private JPanel boardpanel;	
	private Graphics2D g; 	
	private int x4, y4; 	
	public DrawListener(JPanel boardpanel) {		
		// TODO Auto-generated constructor stub		
		this.boardpanel = boardpanel;	
		} 	
	@Override	
	public void actionPerformed(ActionEvent e) {			
		JMenuItem b = (JMenuItem) e.getSource();			
		Shape = b.getActionCommand();			
		System.out.println(Shape); 		
	} 	
	@Override	
	public void mouseClicked(MouseEvent arg0) {		
		// TODO Auto-generated method stub 	
	} 	
	@Override	
	public void mouseEntered(MouseEvent arg0) {		
		// TODO Auto-generated method stub 	
	} 	
	@Override	
	public void mouseExited(MouseEvent arg0) {		
		// TODO Auto-generated method stub 	
	} 	
	@Override	
	public void mousePressed(MouseEvent arg0) {		
		// TODO Auto-generated method stub 		
		x1 = arg0.getX();		
		y1 = arg0.getY(); 	
	} 	
	@Override	
	public void mouseReleased(MouseEvent arg0) { 		
		x2 = arg0.getX();	
		y2 = arg0.getY();		
		g = (Graphics2D) 
		boardpanel.getGraphics();		
		g.setColor(color); 		
		if (Shape.equals("Line")) { 			
			g.drawLine(x1, y1, x2, y2); 	
		} else if (Shape.equals("Circle")) {
			if(Math.abs(x1 - x2)>Math.abs(y1 - y2)) {
				if (x1 < x2 && y1 < y2) { 	
					g.drawOval(x1, y1, Math.abs(x1 - x2), Math.abs(x1 - x2)); 	
				} else if (x1 > x2 && y1 > y2) { 				
					g.drawOval(x2, y2, Math.abs(x1 - x2), Math.abs(x1 - x2)); 	
				} else if (x1 > x2 && y1 < y2) { 	
					g.drawOval(x2, y1, Math.abs(x1 - x2), Math.abs(x1 - x2)); 			
				} else if (x1 < x2 && y1 > y2) { 				
					g.drawOval(x1, y2, Math.abs(x1 - x2), Math.abs(x1 - x2));	
				} 	
			}else{
				if (x1 < x2 && y1 < y2) { 	
					g.drawOval(x1, y1, Math.abs(y1 - y2), Math.abs(y1 - y2)); 	
				} else if (x1 > x2 && y1 > y2) { 				
					g.drawOval(x2, y2, Math.abs(y1 - y2), Math.abs(y1 - y2)); 	
				} else if (x1 > x2 && y1 < y2) { 	
					g.drawOval(x2, y1, Math.abs(y1 - y2), Math.abs(y1 - y2)); 			
				} else if (x1 < x2 && y1 > y2) { 				
					g.drawOval(x1, y2, Math.abs(y1 - y2), Math.abs(y1 - y2));	
				} 
				// g.drawOval(x1, y1, x2 / 2, y2 / 2);	
			}
			} else if (Shape.equals("Rectangle")) { 	
				if (x1 < x2 && y1 < y2) { 	
					g.drawRect(x1, y1, Math.abs(x1 - x2), Math.abs(y1 - y2)); 
				} else if (x1 > x2 && y1 > y2) {	
					g.clearRect(x2, y2, Math.abs(x1 - x2), Math.abs(y1 - y2));	
					g.drawRect(x2, y2, Math.abs(x1 - x2), Math.abs(y1 - y2)); 			
				} else if (x1 > x2 && y1 < y2) {				
					g.clearRect(x2, y1, Math.abs(x1 - x2), Math.abs(y1 - y2));				
					g.drawRect(x2, y1, Math.abs(x1 - x2), Math.abs(y1 - y2));			
				} else if (x1 < x2 && y1 > y2) {				
					g.clearRect(x1, y2, Math.abs(x1 - x2), Math.abs(y1 - y2));				
					g.drawRect(x1, y2, Math.abs(x1 - x2), Math.abs(y1 - y2));			
				} 		
			} else if (Shape.equals("Oval")) {			
				if (x1 < x2 && y1 < y2) {				
					g.drawOval(x1, y1, Math.abs(x1 - x2), Math.abs(y1 - y2)); 	
				} else if (x1 > x2 && y1 > y2) {				
					g.drawOval(x2, y2, Math.abs(x1 - x2), Math.abs(y1 - y2));			
				} else if (x1 > x2 && y1 < y2) {				
					g.drawOval(x2, y1, Math.abs(x1 - x2), Math.abs(y1 - y2));			
				} else if (x1 < x2 && y1 > y2) {				
					g.drawOval(x1, y2, Math.abs(x1 - x2), Math.abs(y1 - y2));			
				} 		
			}
		} 	
	@Override	
	public void mouseDragged(MouseEvent arg0) {		// TODO Auto-generated method stub 		
		g = (Graphics2D) boardpanel.getGraphics();		
		g.setColor(color);		
		x2 = arg0.getX();		
		y2 = arg0.getY(); 
		if (Shape.equals("Draw Pen")) { 			
			g.drawLine(x1, y1, x2, y2);			
			x1 = x2;			
			y1 = y2; 		
		} else if(Shape.equals("Painting Brush")) {
			g.setStroke(new BasicStroke(7f));
			g.drawLine(x1, y1, x2, y2);			
			x1 = x2;			
			y1 = y2;
		}else if (Shape.equals("Line")) { 			
			g.drawLine(x1, y1, x2, y2); 			
			try { 				
				boardpanel.repaint();				
				Thread.sleep(100); 			
			} catch (InterruptedException e) {				
				// TODO Auto-generated catch block				
				e.printStackTrace();			
			}			
			g.dispose();		
		} else if (Shape.equals("Circle")) {			
			if (x1 < x2 && y1 < y2) { 				
				g.drawOval(x1, y1, Math.abs(x1 - x2), Math.abs(y1 - y2)); 				
				try {					
					boardpanel.repaint();					
					Thread.sleep(100); 				
				} catch (InterruptedException e) {					
					// TODO Auto-generated catch block					
					e.printStackTrace();				
				}	
			} else if (x1 > x2 && y1 > y2) { 				
				g.drawOval(x2, y2, Math.abs(x1 - x2), Math.abs(y1 - y2)); 		
			} else if (x1 > x2 && y1 < y2) { 				
				g.drawOval(x2, y1, Math.abs(x1 - x2), Math.abs(y1 - y2)); 			
			} else if (x1 < x2 && y1 > y2) { 				
				g.drawOval(x1, y2, Math.abs(x1 - x2), Math.abs(y1 - y2));			
			} 			// g.drawOval(x1, y1, x2 / 2, y2 / 2);		
		} else if (Shape.equals("Rectangle")) { 			
			if (x1 < x2 && y1 < y2) {				
				// g.clearRect(x1, y1, Math.abs(x1 - x2), Math.abs(y1 - y2)); 				
				g.drawRect(x1, y1, Math.abs(x1 - x2), Math.abs(y1 - y2)); 				
				try {					
					boardpanel.repaint();					
					Thread.sleep(100); 				
				} catch (InterruptedException e) {					
					// TODO Auto-generated catch block				
					e.printStackTrace();			
				} 			
			} else if (x1 > x2 && y1 > y2) {	
				g.clearRect(x2, y2, Math.abs(x1 - x2), Math.abs(y1 - y2));	
				g.drawRect(x2, y2, Math.abs(x1 - x2), Math.abs(y1 - y2)); 		
			} else if (x1 > x2 && y1 < y2) {				
				g.clearRect(x2, y1, Math.abs(x1 - x2), Math.abs(y1 - y2));	
				g.drawRect(x2, y1, Math.abs(x1 - x2), Math.abs(y1 - y2));	
			} else if (x1 < x2 && y1 > y2) {			
				g.clearRect(x1, y2, Math.abs(x1 - x2), Math.abs(y1 - y2));	
				g.drawRect(x1, y2, Math.abs(x1 - x2), Math.abs(y1 - y2));	
			} 		
		} else if (Shape.equals("Oval")) {			
			if (x1 < x2 && y1 < y2) {			
				try {				
					boardpanel.repaint();				
					Thread.sleep(150); 			
				} catch (InterruptedException e) {		
					// TODO Auto-generated catch block		
					e.printStackTrace();				
				}				
				g.drawOval(x1, y1, Math.abs(x1 - x2), Math.abs(y1 - y2));	
			} else if (x1 > x2 && y1 > y2) {			
				g.drawOval(x2, y2, Math.abs(x1 - x2), Math.abs(y1 - y2));		
			} else if (x1 > x2 && y1 < y2) {			
				g.drawOval(x2, y1, Math.abs(x1 - x2), Math.abs(y1 - y2));	
			} else if (x1 < x2 && y1 > y2) {			
				g.drawOval(x1, y2, Math.abs(x1 - x2), Math.abs(y1 - y2));	
			} 		
		} 	
	} 	
	@Override	public void mouseMoved(MouseEvent arg0) {	
		// TODO Auto-generated method stub		
		g = (Graphics2D) boardpanel.getGraphics();	
		g.setColor(Color.white);		
		x4 = arg0.getX();	
		y4 = arg0.getY();	
		if (Shape.equals("Eraser")) { 	
			g.fillOval(x4, y4, x2, y2);		
		} 	
	} 
}
