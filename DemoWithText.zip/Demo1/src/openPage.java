import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.rmi.RemoteException;

public class openPage extends JFrame {
	static String[] listData=new String[20];
	static int onlineIndex=0;
	static JList list=new JList();
	static JTextArea j;
	static DefaultListModel dlm;
	
	static String[] userData= new String[20];
    static int userIndex=3;
	static JComboBox applycomboBox = new JComboBox();
	static JComboBox usercomboBox = new JComboBox();
	static String[] message=new String[200]; 
	static int mesIndex=0;
	
    public static JTextField username = new JTextField();
    public static String thisIp="10.27.76.789";
    public static int thisPort=8090;
    public static String commond;
    public static String users;
    public static JFrame frameOne = new JFrame("WhiteBoard");//input usernmae
    public static JFrame frameTwo;//choose create or join
    public static JFrame frameThree;//show which whiteboard can be joined
    public static JFrame frameFour;//waiting for the answer of the request
    public static JFrame frameFive;//create a whiteboard
    public static String[] usernames;
    public static int numofWB=0;
    static String[] applyData=new String[20]; 
    static int applyIndex=3;
    public static WhiteBoard[] whiteBoards=new WhiteBoard[100];
    public static String[] boardinfo=new String[100];
    public static JLabel showPick;
    public static void main(String[] args) {
        JPanel enterPage = new JPanel();
        firstPage(frameOne, enterPage);
        usernames = new String[]{"andy", "cindy", "tommy"};
        boardinfo[0]="100000"+" "+"8090";
        boardinfo[1]="100001"+" "+"8091";
        boardinfo[2]="100002"+" "+"8092";
        boardinfo[3]="100003"+" "+"8093";
        boardinfo[4]="100004"+" "+"8094";
        boardinfo[5]="100005"+" "+"8095";
    }

    static class buttonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            commond = e.getActionCommand();
            if (commond.equals("e")) {
                users = username.getText();
                if(userExit(usernames,users)){
                    waringPage();
                }
                else{
                    secondPage(users);
                }

            }
            if (commond.equals("c")) {
                users = username.getText();
                try {
                    RemoteWhiteBoard centerPeer = new RemoteWhiteBoard("center", true, null);
                } catch (RemoteException en) {
                    en.printStackTrace();
                }
            }
            if (commond.equals("j")) {
                users = username.getText();
                joinPage(users);
            }
            if (commond.equals("s")) {
                String[] pick=showPick.getText().split(" ");
                waitPage(pick[0],pick[1]);
            }
            if (commond.equals("n")) {
                add();
            }

        }
    }
    public static void add(){
        whiteBoards[numofWB]=new WhiteBoard();
        whiteBoards[numofWB].setManager(users);
        whiteBoards[numofWB].setPort(thisPort);
        whiteBoards[numofWB].setIpaddress(thisIp);
        System.out.println(whiteBoards[numofWB].getManager()+" "+whiteBoards[numofWB].getPort()+" "
                +whiteBoards[numofWB].getIpaddress());
        //boardinfo[numofWB]=(whiteBoards[numofWB].getManager()+" "+whiteBoards[numofWB].getPort()+" "
                //+whiteBoards[numofWB].getIpaddress());
        numofWB++;
        System.out.println(numofWB);
    }
    public static void firstPage(JFrame frameone, JPanel enterPage) {
        frameone.setBounds(700, 200, 380, 500);
        frameone.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameone.add(enterPage);
        enterPage.setOpaque(false);
        enterPage.setLayout(null);
        JLabel user = new JLabel("Please input your username");
        JButton enter = new JButton("enter");
        enter.setActionCommand("e");
        enter.addActionListener(new buttonListener());
        user.setBounds(100, 100, 200, 80);
        username.setBounds(100, 180, 200, 40);
        enter.setBounds(250, 280, 70, 40);
        enterPage.add(enter);
        enterPage.add(username);
        enterPage.add(user);
        enterPage.setVisible(true);
        frameone.setVisible(true);
    }
    public static void waringPage(){
        JFrame warning =new JFrame("Warning");
        warning.setVisible(true);
        warning.setBounds(500,200,300,300);
        JPanel warningPanel=new JPanel();
        warning.add(warningPanel);
        warningPanel.setOpaque(false);
        warningPanel.setLayout(null);
        JLabel w=new JLabel("This username already exits");
        w.setBounds(100,100,200,80);
        warningPanel.add(w);
        warningPanel.setVisible(true);
        warning.setVisible(true);
    }

    public static void secondPage(String a) {
        frameOne.setVisible(false);
        frameTwo = new JFrame(a);
        JPanel secondPage = new JPanel();
        frameTwo.setBounds(700, 200, 380, 500);
        frameTwo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameTwo.add(secondPage);
        secondPage.setOpaque(false);
        secondPage.setLayout(null);
        JButton create = new JButton("create");
        JButton join = new JButton("join");
        create.setActionCommand("c");
        join.setActionCommand("j");
        create.addActionListener(new buttonListener());
        join.addActionListener(new buttonListener());
        create.setBounds(160, 250, 100, 40);
        secondPage.add(create);
        join.setBounds(160, 350, 100, 40);
        secondPage.add(join);
        secondPage.setVisible(true);
        frameTwo.setVisible(true);
    }

    public static void joinPage(String a) {
        //frameTwo.setVisible(false);
        frameThree = new JFrame(a);
        JPanel thirdPage = new JPanel();
        frameThree.setBounds(700, 200, 500, 550);
        frameThree.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameThree.add(thirdPage);
        thirdPage.setOpaque(false);
        thirdPage.setLayout(null);
        JList<String> boardInfo = new JList(boardinfo);
        boardInfo.setBounds(40, 80, 400, 200);
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(40, 80, 400, 200);
        scrollPane.setViewportView(boardInfo);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        boardInfo.setVisibleRowCount(boardinfo.length);
        showPick=new JLabel();
        showPick.setBounds(40,350,150,40);
        boardInfo.addListSelectionListener(new ListSelectionListener(){
            @Override
            public void valueChanged(ListSelectionEvent e) {
                StringBuilder text = new StringBuilder("");
                for(String value : boardInfo.getSelectedValuesList()){
                    text.append(value);
                }
                showPick.setText(text.toString());
            }
        });
        JLabel note = new JLabel("You can join following whitebord(s)");
        note.setBounds(40, 40, 400, 40);

        JButton joinButton = new JButton("Send a join request");
        joinButton.setBounds(40, 440, 150, 40);
        joinButton.setActionCommand("s");
        //joinButton.addActionListener(new buttonListener());
        joinButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	applyData[applyIndex]=users;
            	applyIndex++;
            	String[] pick=showPick.getText().split(" ");
                waitPage(pick[0],pick[1]);
            }
        });
        thirdPage.add(scrollPane);
        thirdPage.add(note);
        thirdPage.add(joinButton);
        thirdPage.add(showPick);
        thirdPage.setVisible(true);
        frameThree.setVisible(true);
        System.out.println(showPick.getText());
    }

    public static void waitPage(String ipaddress, String port) {
        String answer = "Successful";
        frameThree.setVisible(false);
        frameFour = new JFrame("waiting");
        JPanel forthPage = new JPanel();
        frameFour.setBounds(700, 200, 500, 500);
        frameFour.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameFour.add(forthPage);
        forthPage.setOpaque(false);
        forthPage.setLayout(null);
        JTextArea waitInfo = new JTextArea();
        waitInfo.setBounds(40, 80, 400, 200);
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(40, 80, 400, 200);
        scrollPane.setViewportView(waitInfo);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        waitInfo.setText("***Waiting to Connect***" + "\n");
        waitInfo.append("IP Address is: " + ipaddress + "\n");
        waitInfo.append("Port is:       " + port + "\n");
        waitInfo.append(answer);
        forthPage.add(waitInfo);
        forthPage.setVisible(true);
        frameFour.setVisible(true);
        try {
            RemoteWhiteBoard centerPeer = new RemoteWhiteBoard("center", true, null);
        } catch (RemoteException en) {
            en.printStackTrace();
        }
    }

    public static void createPage() {
        //frameTwo.setVisible(false);
        frameFive = new JFrame();
        frameFive.setBounds(700, 200, 380, 500);
        JPanel fifthPage = new JPanel();
        frameFive.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameFive.add(fifthPage);
        JButton newFile=new JButton("new");
        newFile.setActionCommand("n");
        newFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    RemoteWhiteBoard centerPeer = new RemoteWhiteBoard("center", true, null);
                } catch (RemoteException en) {
                    en.printStackTrace();
                }
            }
        });
        //newFile.addActionListener(new buttonListener());
        newFile.setBounds(50, 280, 70, 40);
        JButton exit=new JButton("Exit");
        exit.setActionCommand("E");
        exit.addActionListener(new buttonListener());
        exit.setBounds(250, 280, 70, 40);
        fifthPage.add(newFile);
        fifthPage.add(exit);
        fifthPage.setOpaque(false);
        fifthPage.setLayout(null);
        fifthPage.setVisible(true);
        frameFive.setVisible(true);
    }

    public static boolean userExit(String[] usernames, String users) {
        for (int i = 0; i < usernames.length; i++) {
            if (usernames[i].equals(users))
                return true;
        }
        return false;
    }
    public static String FileChooser(){
    	JFileChooser jfc=new JFileChooser();
        jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES );
        jfc.showDialog(new JLabel(), "Select");
        File file=jfc.getSelectedFile();
        return file.getAbsolutePath();
    }
    public static void userWhiteboard() {
        JPanel contentPane;
        JFrame frame = new JFrame("User");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100, 100, 695, 445);


        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        frame.setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel boardpanel = new JPanel();
        boardpanel.setBackground(Color.white);
        boardpanel.setBounds(156, 30, 312, 342);
        contentPane.add(boardpanel);

        DrawListener dl = new DrawListener(boardpanel);
        boardpanel.addMouseListener(dl);
        boardpanel.addMouseMotionListener(dl);


        JMenuBar menuBar = new JMenuBar();
        menuBar.setToolTipText("File");
        menuBar.setForeground(new Color(201, 154, 236));
        menuBar.setFont(new Font("Georgia", Font.PLAIN, 12));
        menuBar.setMargin(new Insets(0, 0, 0, 50));
        frame.setJMenuBar(menuBar);
        JMenu mnFile = new JMenu("File");
        mnFile.setFont(new Font("Georgia", Font.PLAIN, 12));
        menuBar.add(mnFile);
        JMenuItem mntmOpen = new JMenuItem("Open");
        mntmOpen.setFont(new Font("Georgia", Font.PLAIN, 12));
        mntmOpen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
        mnFile.add(mntmOpen);
        mntmOpen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userWhiteboard();
            }
        });

        JMenuItem mntmSave = new JMenuItem("Save");
        mntmSave.setFont(new Font("Georgia", Font.PLAIN, 12));
        mntmSave.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK));
        mnFile.add(mntmSave);
        mntmSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        });

        JMenuItem mntmSaveAs = new JMenuItem("Save As");
        mntmSaveAs.setFont(new Font("Georgia", Font.PLAIN, 12));
        mntmSaveAs.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.CTRL_MASK));
        mnFile.add(mntmSaveAs);
        mntmSaveAs.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String path = FileChooser();
                System.out.print(path);
            }
        });

        JMenuItem mntmClose = new JMenuItem("Close");
        mntmClose.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.CTRL_MASK));
        mntmClose.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnFile.add(mntmClose);
        mntmClose.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        JMenu mnShape = new JMenu("Shape");
        mnShape.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnShape.setHorizontalAlignment(SwingConstants.LEFT);
        menuBar.add(mnShape);

        JMenuItem mntmLine = new JMenuItem("Line");
        mntmLine.setIcon(new ImageIcon("icon/line.png"));
        mntmLine.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnShape.add(mntmLine);
        mntmLine.addActionListener(dl);

        JMenuItem mntmCircle = new JMenuItem("Circle");
        mntmCircle.setIcon(new ImageIcon("icon/circle.png"));
        mntmCircle.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnShape.add(mntmCircle);
        mntmCircle.addActionListener(dl);

        JMenuItem mntmRectangle = new JMenuItem("Rectangle");
        mntmRectangle.setIcon(new ImageIcon("icon/rect.png"));
        mntmRectangle.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnShape.add(mntmRectangle);
        mntmRectangle.addActionListener(dl);

        JMenuItem mntmOval = new JMenuItem("Oval");
        mntmOval.setIcon(new ImageIcon("icon/oval.png"));
        mntmOval.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnShape.add(mntmOval);
        mntmOval.addActionListener(dl);

        JMenu mnStyle = new JMenu("Style");
        mnStyle.setFont(new Font("Georgia", Font.PLAIN, 12));
        menuBar.add(mnStyle);

        JMenuItem mntmColor = new JMenuItem("Color");
        mntmColor.setIcon(new ImageIcon("icon/color.png"));
        mntmColor.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnStyle.add(mntmColor);
        mntmColor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame colorFrame = new JFrame("Color box");
                dl.color = JColorChooser.showDialog(frame, "Select color", null);
                System.out.print(dl.color);
            }
        });

        JMenuItem mntmFont = new JMenuItem("Font");
        mntmFont.setIcon(new ImageIcon("icon/font.png"));
        mntmFont.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnStyle.add(mntmFont);

        JMenuItem mntmSize = new JMenuItem("Size");
        mntmSize.setIcon(new ImageIcon("icon/size.png"));
        mntmSize.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnStyle.add(mntmSize);

        JMenu mnTool = new JMenu("Tool");
        mnTool.setFont(new Font("Georgia", Font.PLAIN, 12));
        menuBar.add(mnTool);

        JMenuItem mntmEraser = new JMenuItem("Eraser");
        mntmEraser.setIcon(new ImageIcon("icon/eraser.png"));
        mntmEraser.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnTool.add(mntmEraser);
        mntmEraser.addActionListener(dl);

        JMenuItem mntmBrush = new JMenuItem("Painting Brush");
        mntmBrush.setIcon(new ImageIcon("icon/brush.png"));
        mntmBrush.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnTool.add(mntmBrush);
        mntmBrush.addActionListener(dl);

        JMenuItem mntmPen = new JMenuItem("Draw Pen");
        mntmPen.setIcon(new ImageIcon("icon/pen.png"));
        mntmPen.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnTool.add(mntmPen);
        mntmPen.addActionListener(dl);

        JMenu mnInsert = new JMenu("Insert");
        mnInsert.setFont(new Font("Georgia", Font.PLAIN, 12));
        menuBar.add(mnInsert);

        JMenuItem mntmText = new JMenuItem("Text");
        mntmText.setIcon(new ImageIcon("icon/text.png"));
        mntmText.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnInsert.add(mntmText);

        JMenuItem mntmPic = new JMenuItem("Picture");
        mntmPic.setIcon(new ImageIcon("icon/pic.png"));
        mntmPic.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnInsert.add(mntmPic);
        mntmPic.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String path = FileChooser();
                System.out.print(path);
            }
        });

        JButton btnSend = new JButton("Send");
        btnSend.setFont(new Font("Georgia", Font.PLAIN, 12));
        btnSend.setBounds(559, 351, 93, 23);
        contentPane.add(btnSend);
        JTextArea textField = new JTextArea();
        textField.setBounds(493, 230, 165, 113);
        contentPane.add(textField);

        JTextArea jta = new JTextArea(50, 15);
        jta.setFont(new Font("Georgia", Font.PLAIN, 12));
        jta.setLineWrap(true);
        JScrollPane jsp = new JScrollPane(jta);    //���ı�������������
        jsp.setBounds(495, 30, 165, 180);
        contentPane.add(jsp);
        btnSend.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //message[mesIndex]="Me: "+ textField.getText();
                jta.append("Me: " + textField.getText());
                jta.paintImmediately(jta.getBounds());
                //mesIndex++;
            }
        });

        JLabel title = new JLabel("Online Users:");
        title.setBounds(10, 10, 113, 29);
        title.setFont(new Font("Georgia", Font.PLAIN, 12));
        contentPane.add(title);
        dlm = new DefaultListModel();
        JScrollPane s = new JScrollPane();
        dlm.addElement("ad");
        contentPane.add(s);
        list.setBounds(20, 31, 79, 142);
        contentPane.add(list);
        list.setModel(dlm);
        JLabel lblChart = new JLabel("Chart");
        lblChart.setFont(new Font("Georgia", Font.PLAIN, 12));
        lblChart.setBounds(539, 10, 113, 29);
        contentPane.add(lblChart);
        frame.setVisible(true);
    }
}

