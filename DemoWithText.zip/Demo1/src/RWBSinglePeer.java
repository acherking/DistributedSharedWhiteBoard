import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.rmi.RemoteException;
import java.util.Vector;

public class RWBSinglePeer {
    private Vector<RemoteWhiteBoard> RWBsList;
    private JFrame mainJFrame;
    private JTextField inputRWBName;

    public RWBSinglePeer() {
        RWBsList = new Vector<>();
        prepareGUI();
    }

    private void prepareGUI() {
        mainJFrame = new JFrame("RWBSinglePeer");
        mainJFrame.setSize(200, 300);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new FlowLayout());
        mainJFrame.add(mainPanel, BorderLayout.CENTER);

        Font inputRWBNameFont = new Font("Monaco", Font.PLAIN, 18);
        inputRWBName = new JTextField("White-Board Name", 11);
        inputRWBName.setFont(inputRWBNameFont);
        mainPanel.add(inputRWBName);

        JButton createButton = new JButton("Create");
        JButton connectButton = new JButton("Connect");
        createButton.setActionCommand("Create");
        connectButton.setActionCommand("Connect");
        createButton.addActionListener(new ButtonClickListener());
        connectButton.addActionListener(new ButtonClickListener());
        mainPanel.add(createButton);
        mainPanel.add(connectButton);

        mainJFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent){
                System.exit(0);
            }
        });
    }

    private void showGUI() {
        mainJFrame.setVisible(true);
    }

    public static void main(String[] args) {
        try {
            RemoteWhiteBoard centerPeer = new RemoteWhiteBoard("center", true, null);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    private class ButtonClickListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

        }
    }
}
