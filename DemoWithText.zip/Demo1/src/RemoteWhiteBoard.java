import remote.IRemoteWhiteBoard;
import remote.MyShape;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.font.FontRenderContext;
import java.awt.font.TextLayout;
import java.awt.geom.*;
import java.io.*;
import java.net.URL;
import java.net.URLDecoder;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class RemoteWhiteBoard extends UnicastRemoteObject implements IRemoteWhiteBoard {
    private String s="Line";
    private Color c=Color.BLACK;
    private String[] userData= new String[20];
    static int userIndex=0;
    static JComboBox applycomboBox = new JComboBox();
    static JComboBox usercomboBox = new JComboBox();
    static String[] message=new String[200];
    static int mesIndex=0;
    static String[] applyData=new String[20];
    static int applyIndex=3;
    static JList list=new JList();
    static JTextArea j;
    static DefaultListModel dlm;
    private JPanel contentPane;
    private JFrame baseJFrame;
    //private ToolBar toolBar;
    private PaintSurface paintSurface;
    private String userName;
    private boolean isCenter;
    private IRemoteWhiteBoard centerWhiteBoard;
    private ConcurrentHashMap<String, IRemoteWhiteBoard> rWhiteBoards;
    private JTextField fileNameText;
    private JFrame save=new JFrame("save");
    private JFrame saveSuccessfulOrNot;
    private JFrame open;
    private JFrame saveas=new JFrame("saveas");

    public Image addPic(String path) {//Get image from the given path.
        Image img=null;
        URL url = RemoteWhiteBoard.class.getResource(path);
        try {
        	InputStream input=url.openStream();
        	img=ImageIO.read(input);
        }catch(IOException e) {
        	System.out.print("Problem with get the image through path: "+path+"\n");
        }
        return img;
	}
    public RemoteWhiteBoard() throws RemoteException {
        this.userName = "initName";
        this.isCenter = false;
        this.centerWhiteBoard = null;
        this.rWhiteBoards = null;

        baseJFrame = new JFrame();
        baseJFrame.setBounds(100, 100, 1000, 700);
       
        baseJFrame.addWindowListener(new myWindowListener());

        /*
        contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		baseJFrame.setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea textField = new JTextArea();
		textField.setBounds(493, 230, 165, 113);
		contentPane.add(textField);*/
        
		
        paintSurface = new PaintSurface();
        paintSurface.setBounds(156, 30, 312, 342);
        baseJFrame.add(paintSurface,BorderLayout.CENTER);
        
        //paintSurface.setBackground(Color.WHITE);
        //contentPane.add(paintSurface);

        JMenuBar menuBar = new JMenuBar();
        menuBar.setToolTipText("File");
        menuBar.setForeground(new Color(0, 0, 0));
        menuBar.setFont(new Font("Georgia", Font.PLAIN, 12));
        menuBar.setMargin(new Insets(0, 0, 0, 50));

        JMenu mnFile = new JMenu("File");
        mnFile.setFont(new Font("Georgia", Font.PLAIN, 12));
        menuBar.add(mnFile);

        JMenuItem mntmOpen = new JMenuItem("Open");
        mntmOpen.setFont(new Font("Georgia", Font.PLAIN, 12));
        mntmOpen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
        mnFile.add(mntmOpen);
        mntmOpen.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                open();
            }
        });


        JMenuItem mntmSave = new JMenuItem("Save");
        mntmSave.setFont(new Font("Georgia", Font.PLAIN, 12));
        mntmSave.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK));
        mnFile.add(mntmSave);
        mntmSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                save();
            }
        });


        JMenuItem mntmSaveAs = new JMenuItem("Save As");
        mntmSaveAs.setFont(new Font("Georgia", Font.PLAIN, 12));
        mntmSaveAs.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.CTRL_MASK));
        mnFile.add(mntmSaveAs);
        mntmSaveAs.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveas();
            }
        });

        JMenuItem mntmClose = new JMenuItem("Close");
        mntmClose.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.CTRL_MASK));
        mntmClose.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnFile.add(mntmClose);
        mntmClose.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                baseJFrame.setVisible(false);
            }
        });

        JMenu mnShape = new JMenu("Shape");
        mnShape.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnShape.setHorizontalAlignment(SwingConstants.LEFT);
        menuBar.add(mnShape);

        JMenuItem mntmLine = new JMenuItem("Line");
        mntmLine.setIcon(new ImageIcon(addPic("/icon/line.png")));
        mntmLine.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnShape.add(mntmLine);
        mntmLine.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="Line";
            }
        });

        JMenuItem mntmCircle = new JMenuItem("Circle");
        mntmCircle.setIcon(new ImageIcon(addPic("/icon/circle.png")));
        mntmCircle.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnShape.add(mntmCircle);
        mntmCircle.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="Circle";
            }
        });

        JMenuItem mntmRectangle = new JMenuItem("Rectangle");
        mntmRectangle.setIcon(new ImageIcon(addPic("/icon/rect.png")));
        mntmRectangle.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnShape.add(mntmRectangle);
        mntmRectangle.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="Rectangle";
            }
        });

        JMenuItem mntmOval = new JMenuItem("Oval");
        mntmOval.setIcon(new ImageIcon(addPic("/icon/oval.png")));
        mntmOval.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnShape.add(mntmOval);
        mntmOval.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="Oval";
            }
        });



        JMenuItem mntmCircleF = new JMenuItem("Filled Circle");
        mntmCircleF.setIcon(new ImageIcon(addPic("/icon/circlef.png")));
        mntmCircleF.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnShape.add(mntmCircleF);
        mntmCircleF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="CircleF";
                //System.out.print(s);
            }
        });

        JMenuItem mntmRectangleF = new JMenuItem("Filled Rectangle");
        mntmRectangleF.setIcon(new ImageIcon(addPic("/icon/rectf.png")));
        mntmRectangleF.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnShape.add(mntmRectangleF);
        mntmRectangleF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="RectangleF";
            }
        });

        JMenuItem mntmOvalF = new JMenuItem("Filled Oval");
        mntmOvalF.setIcon(new ImageIcon(addPic("/icon/ovalf.png")));
        mntmOvalF.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnShape.add(mntmOvalF);
        mntmOvalF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="OvalF";
            }
        });
        JMenu mnStyle = new JMenu("Color");
		mnStyle.setFont(new Font("Georgia", Font.PLAIN, 12));
		menuBar.add(mnStyle);
		
		JMenuItem mntmRed = new JMenuItem();
		mntmRed.setBackground(Color.RED);
		mnStyle.add(mntmRed);
		mntmRed.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.RED;
			}
		});
		
		JMenuItem mntmOrange = new JMenuItem();
		mntmOrange.setBackground(Color.ORANGE);
		mnStyle.add(mntmOrange);
		mntmOrange.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.ORANGE;
			}
		});
		
		JMenuItem mntmYellow = new JMenuItem();
		mntmYellow.setBackground(Color.YELLOW);
		mnStyle.add(mntmYellow);
		mntmYellow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.YELLOW;
			}
		});
		
		JMenuItem mntmGreen = new JMenuItem();
		mntmGreen.setBackground(Color.GREEN);
		mnStyle.add(mntmGreen);
		mntmGreen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.GREEN;
			}
		});
		
		JMenuItem mntmCyan = new JMenuItem();
		mntmCyan.setBackground(Color.CYAN);
		mnStyle.add(mntmCyan);
		mntmCyan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.CYAN;
			}
		});
		
		JMenuItem mntmBlue = new JMenuItem();
		mntmBlue.setBackground(Color.BLUE);
		mnStyle.add(mntmBlue);
		mntmBlue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.BLUE;
			}
		});
		
		JMenuItem mntmMagenta = new JMenuItem();
		mntmMagenta.setBackground(Color.MAGENTA);
		mnStyle.add(mntmMagenta);
		mntmMagenta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.MAGENTA;
			}
		});
		
		JMenuItem mntmPink = new JMenuItem();
		mntmPink.setBackground(Color.PINK);
		mnStyle.add(mntmPink);
		mntmPink.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.PINK;
			}
		});
		
		JMenuItem mntmBlack = new JMenuItem();
		mntmBlack.setBackground(Color.BLACK);
		mnStyle.add(mntmBlack);
		mntmBlack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.BLACK;
			}
		});
		
		JMenuItem mntmWhite = new JMenuItem();
		mntmWhite.setBackground(Color.WHITE);
		mnStyle.add(mntmWhite);
		mntmWhite.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.WHITE;
			}
		});
		
		JMenuItem mntmGray = new JMenuItem();
		mntmGray.setBackground(Color.GRAY);
		mnStyle.add(mntmGray);
		mntmGray.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.GRAY;
			}
		});
		
		JMenuItem mntmOlive = new JMenuItem();
		mntmOlive.setBackground(new Color(128, 128, 0));
		mnStyle.add(mntmOlive);
		mntmOlive.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=new Color(128, 128, 0);
			}
		});
		
		JMenuItem mntmPeru = new JMenuItem();
		mntmPeru.setBackground(new Color(205, 133, 63));
		mnStyle.add(mntmPeru);
		mntmPeru.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=new Color(205, 133, 63);
			}
		});
		
		JMenuItem mntmTeal = new JMenuItem();
		mntmTeal.setBackground(new Color(0, 128, 128));
		mnStyle.add(mntmTeal);
		mntmTeal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=new Color(0, 128, 128);
			}
		});
		
		JMenuItem mntmTomato = new JMenuItem();
		mntmTomato.setBackground(new Color(255, 99, 71));
		mnStyle.add(mntmTomato);
		mntmTomato.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=new Color(255, 99, 71);
			}
		});
		
		JMenuItem mntmBisque = new JMenuItem();
		mntmBisque.setBackground(new Color(255, 228, 196));
		mnStyle.add(mntmBisque);
		mntmBisque.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=new Color(255, 228, 196);
			}
		});

        JMenu mnTool = new JMenu("Tool");
        mnTool.setFont(new Font("Georgia", Font.PLAIN, 12));
        menuBar.add(mnTool);

        JMenuItem mntmEraserS = new JMenuItem("Small Eraser");
        mntmEraserS.setIcon(new ImageIcon(addPic("/icon/eraser.png")));
        mntmEraserS.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnTool.add(mntmEraserS);
        mntmEraserS.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="EraserS";
            }
        });
        
        JMenuItem mntmEraserM = new JMenuItem("Medium Eraser");
        mntmEraserM.setIcon(new ImageIcon(addPic("/icon/eraser.png")));
        mntmEraserM.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnTool.add(mntmEraserM);
        mntmEraserM.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="EraserM";
            }
        });
        
        
        JMenuItem mntmEraserL = new JMenuItem("Large Eraser");
        mntmEraserL.setIcon(new ImageIcon(addPic("/icon/eraser.png")));
        mntmEraserL.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnTool.add(mntmEraserL);
        mntmEraserL.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="EraserL";
            }
        });

        JMenuItem mntmBrush = new JMenuItem("Painting Brush");
        mntmBrush.setIcon(new ImageIcon(addPic("/icon/brush.png")));
        mntmBrush.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnTool.add(mntmBrush);
        mntmBrush.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="Painting Brush";
            }
        });


        JMenuItem mntmPen = new JMenuItem("Draw Pen");
        mntmPen.setIcon(new ImageIcon(addPic("/icon/pen.png")));
        mntmPen.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnTool.add(mntmPen);
        mntmPen.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="Draw Pen";
            }
        });

        JMenu mnInsert = new JMenu("Insert");
        mnInsert.setFont(new Font("Georgia", Font.PLAIN, 12));
        menuBar.add(mnInsert);

        JMenuItem mntmText = new JMenuItem("Text");
        mntmText.setIcon(new ImageIcon(addPic("/icon/text.png")));
        mntmText.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnInsert.add(mntmText);
        mntmText.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="Text";
            }
        });

        JMenuItem mntmPic = new JMenuItem("Picture");
        mntmPic.setIcon(new ImageIcon(addPic("/icon/pic.png")));
        mntmPic.setFont(new Font("Georgia", Font.PLAIN, 12));
        mnInsert.add(mntmPic);
        mntmPic.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                s="Picture";
            }
        });

        baseJFrame.setJMenuBar(menuBar);
    }

    public RemoteWhiteBoard(String userName, boolean isCenter, IRemoteWhiteBoard centerRWB) throws RemoteException {
        this();
        this.userName = userName;
        this.isCenter = isCenter;
        baseJFrame.setTitle(userName);
        if (this.isCenter)  {
            rWhiteBoards = new ConcurrentHashMap<>();
            /*
            JTextArea textField = new JTextArea();
            textField.setBounds(493, 230, 165, 113);
            contentPane.add(textField);
            JTextArea jta=new JTextArea(50,15);
            jta.setFont(new Font("Georgia", Font.PLAIN, 12));
            jta.setLineWrap(true);
            JScrollPane jsp=new JScrollPane(jta);    //閿熸枻鎷烽敓渚ユ唻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷�
            jsp.setBounds(495,30,165,180);
            contentPane.add(jsp);

            JButton btnSend = new JButton("Send");
            btnSend.setFont(new Font("Georgia", Font.PLAIN, 12));
            btnSend.setBounds(559, 351, 93, 23);
            contentPane.add(btnSend);
            btnSend.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    message[mesIndex]="Me: "+ textField.getText();
                    jta.append("Me: "+ textField.getText());
                    jta.paintImmediately(jta.getBounds());
                    mesIndex++;
                }
            });

            JLabel title=new JLabel("Online Users:");
            title.setBounds(10, 10, 113, 29);
            title.setFont(new Font("Georgia", Font.PLAIN, 12));
            //JComboBox usercomboBox = new JComboBox();
            usercomboBox.setBounds(10, 30, 104, 24);
            for(int i=0;i<userIndex;i++) {
                usercomboBox.addItem(userData[i]);
            }
            contentPane.add(title);
            contentPane.add(usercomboBox);
            JButton kickbtn = new JButton("Kick");
            kickbtn.setFont(new Font("Georgia", Font.PLAIN, 12));
            kickbtn.setBounds(10, 64, 79, 23);
            contentPane.add(kickbtn);
            kickbtn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    usercomboBox.removeItem(usercomboBox.getSelectedItem());
                    for(int i=0;i<userIndex;i++) {
                        if(userData[i].equals(usercomboBox.getSelectedItem())) {
                            if(i==userIndex-1) {
                                userData[i]=null;
                                userIndex--;
                            }else {
                                userData[i]=userData[userIndex-1];
                                userData[userIndex-1]=null;
                                userIndex--;
                            }
                        }
                    }
                }

            });

            JLabel lblAppliedUsers = new JLabel("Applied Users:");
            lblAppliedUsers.setFont(new Font("Georgia", Font.PLAIN, 12));
            lblAppliedUsers.setBounds(10, 181, 113, 29);
            contentPane.add(lblAppliedUsers);

            applycomboBox.setBounds(10, 204, 104, 24);
            for(int i=0;i<applyIndex;i++) {
                applycomboBox.addItem(applyData[i]);
            }
            contentPane.add(applycomboBox);

            JButton accbutton = new JButton("Accept");
            accbutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent arg0) {
                    usercomboBox.addItem(applycomboBox.getSelectedItem());
                    userData[userIndex]=applycomboBox.getSelectedItem().toString();
                    userIndex++;
                    applycomboBox.removeItem(applycomboBox.getSelectedItem());
                    for(int i=0;i<applyIndex;i++) {
                        if(applyData[i].equals(applycomboBox.getSelectedItem())) {
                            if(i==applyIndex-1) {
                                applyData[i]=null;
                                applyIndex--;
                            }else {
                                applyData[i]=applyData[applyIndex-1];
                                applyData[applyIndex-1]=null;
                                applyIndex--;
                            }
                        }
                    }
                }
            });
            accbutton.setFont(new Font("Georgia", Font.PLAIN, 12));
            accbutton.setBounds(10, 247, 79, 23);
            contentPane.add(accbutton);

            JButton rebutton= new JButton("Reject");
            rebutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent arg0) {
                    applycomboBox.removeItem(applycomboBox.getSelectedItem());
                    for(int i=0;i<applyIndex;i++) {
                        if(applyData[i].equals(applycomboBox.getSelectedItem())) {
                            if(i==applyIndex-1) {
                                applyData[i]=null;
                                applyIndex--;
                            }else {
                                applyData[i]=applyData[applyIndex-1];
                                applyData[applyIndex-1]=null;
                                applyIndex--;
                            }

                        }
                    }
                }
            });
            rebutton.setFont(new Font("Georgia", Font.PLAIN, 12));
            rebutton.setBounds(10, 280, 79, 23);
            contentPane.add(rebutton);

            JLabel lblChart = new JLabel("Chart");
            lblChart.setFont(new Font("Georgia", Font.PLAIN, 12));
            lblChart.setBounds(539, 10, 113, 29);
            contentPane.add(lblChart);*/
            baseJFrame.setVisible(true);
        }
        else {
            this.centerWhiteBoard = centerRWB;
            /*
            JButton btnSend = new JButton("Send");
            btnSend.setFont(new Font("Georgia", Font.PLAIN, 12));
            btnSend.setBounds(559, 351, 93, 23);
            contentPane.add(btnSend);
            JTextArea textField = new JTextArea();
            textField.setBounds(493, 230, 165, 113);
            contentPane.add(textField);

            JTextArea jta=new JTextArea(50,15);
            jta.setFont(new Font("Georgia", Font.PLAIN, 12));
            jta.setLineWrap(true);
            JScrollPane jsp=new JScrollPane(jta);    //閿熸枻鎷烽敓渚ユ唻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷�
            jsp.setBounds(495,30,165,180);
            contentPane.add(jsp);
            btnSend.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    //message[mesIndex]="Me: "+ textField.getText();
                    jta.append("Me: "+ textField.getText());
                    jta.paintImmediately(jta.getBounds());
                    //mesIndex++;
                }
            });

            JLabel title=new JLabel("Online Users:");
            title.setBounds(10, 10, 113, 29);
            title.setFont(new Font("Georgia", Font.PLAIN, 12));
            contentPane.add(title);
            dlm = new DefaultListModel();
            JScrollPane s=new JScrollPane();
            dlm.addElement("ad");
            contentPane.add(s);
            list.setBounds(20, 31, 79, 142);
            contentPane.add(list);
            list.setModel(dlm);
            JLabel lblChart = new JLabel("Chart");
            lblChart.setFont(new Font("Georgia", Font.PLAIN, 12));
            lblChart.setBounds(539, 10, 113, 29);
            contentPane.add(lblChart);*/
            baseJFrame.setVisible(true);
        }

    }

    @Override
    public void painting(String name, MyShape temperShape) throws RemoteException {
        paintSurface.addTemperShape(name, temperShape);
        paintSurface.repaint();
    }

    @Override
    public void painted(String name, MyShape durableShape) throws RemoteException {
        paintSurface.addDurableShape(name, durableShape);
        paintSurface.repaint();
    }

    // for center
    public void addRemoteWhiteBoard(String name, IRemoteWhiteBoard rwb) {
        rWhiteBoards.put(name, rwb);
    }

    public void removeRemoteWhiteBoard(String name) {
        rWhiteBoards.remove(name);
    }



    protected class PaintSurface extends JComponent {
        private CopyOnWriteArrayList<MyShape> shapes = new CopyOnWriteArrayList<>();
        private ConcurrentHashMap<String, MyShape> temperShapes = new ConcurrentHashMap<>();
        Point startDrag, endDrag;
        Path2D path;
        Point inputPosition;
        String inputString;
        Shape inputStringBound;
        private String fileName;

        private class MyDispatcher implements KeyEventDispatcher {
            private Color textColor = Color.black;
            private float textB = 2;
            @Override
            public boolean dispatchKeyEvent(KeyEvent e) {
                System.out.printf("In mydispatcher, keycode=%d\n", e.getKeyCode());
                if (e.getID() == KeyEvent.KEY_PRESSED) {
                    if (s.equals("Text") && inputPosition!=null && inputString!=null) {
                        char inputChar = e.getKeyChar();
                        if(inputChar>='a' && inputChar<='z') {
                            inputString = inputString + inputChar;
                            Shape s = makeTextLayout();
                            addTemperShape(userName, new MyShape(s, textColor, false, textB));
                            inputStringBound = s.getBounds();
                            repaint();
                        }
                        else if(e.getKeyCode()==KeyEvent.VK_ENTER) {
                            Shape s = makeTextLayout();
                            addDurableShape(userName, new MyShape(s, textColor, false, textB));
                            inputPosition = null;
                            inputString = null;
                            inputStringBound = null;
                            repaint();
                        }
                        else if(e.getKeyCode()==8) {
                            if (inputString.length()>0) {
                                inputString = inputString.substring(0, inputString.length() - 1);
                                if (inputString.length()>0) {
                                    Shape s = makeTextLayout();
                                    addTemperShape(userName, new MyShape(s, textColor, false, textB));
                                    inputStringBound = s.getBounds();
                                }
                                else {
                                    temperShapes.remove(userName);
                                    inputStringBound = null;
                                }
                                repaint();
                            }
                        }
                        else {
                            ;
                        }
                    }
                } else if (e.getID() == KeyEvent.KEY_RELEASED) {
                    ;
                } else if (e.getID() == KeyEvent.KEY_TYPED) {
                    ;
                }
                return false;
            }
        }

        public PaintSurface() {
            inputPosition = null;
            inputString = null;

            KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
            manager.addKeyEventDispatcher(new MyDispatcher());

            this.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    if(s.equals("Text")) {
                        temperShapes.remove(userName);
                        inputStringBound = makeRectangle(e.getX(),e.getY(),e.getX()+30, e.getY()+12);
                        repaint();
                        inputString = new String();
                        inputPosition = new Point(e.getX(), e.getY());
                        return;
                    }
                    startDrag = new Point(e.getX(), e.getY());
                    endDrag = startDrag;
                    path = new Path2D.Float();
                    path.moveTo(e.getX(), e.getY());
                    repaint();
                }
                public void mouseReleased(MouseEvent e) {
                    if(s.equals("Text")) {
                        return;
                    }
                    addDurableShape(userName, createNewShape());
                    startDrag = null;
                    endDrag = null;
                    path = null;
                    repaint();
                }
            });


            this.addMouseMotionListener(new MouseMotionAdapter() {
                public void mouseDragged(MouseEvent e) {
                    if(s.equals("Text")) {
                        return;
                    }
                    endDrag = new Point(e.getX(), e.getY());
                    path.lineTo(e.getX(), e.getY());
                    if(s.equals("EraserS")||s.equals("EraserL")||s.equals("EraserM")) {
                        addDurableShape(userName, createNewShape());
                    }else {
                        addTemperShape(userName, createNewShape());
                    }
                    repaint();
                }
            });
        }
        private void paintBackground(Graphics2D g2){
            /*g2.setPaint(Color.LIGHT_GRAY);
            for (int i = 0; i < getSize().width; i += 10) {
                Shape line = new Line2D.Float(i, 0, i, getSize().height);
                g2.draw(line);
            }

            for (int i = 0; i < getSize().height; i += 10) {
                Shape line = new Line2D.Float(0, i, getSize().width, i);
                g2.draw(line);
            }*/
        	setOpaque(true);
        	setBackground(Color.WHITE);

        }
        public void paint(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            paintBackground(g2);
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setStroke(new BasicStroke(2));
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.50f));

            for (MyShape sh : shapes) {
                g2.setStroke(new BasicStroke(sh.getBasicStroke()));
                g2.setPaint(sh.getColor());
                if(sh.getIsFill()==true) {
                    g2.fill(sh.getShape());
                }else {
                    g2.draw(sh.getShape());
                }
            }

            Set<Map.Entry<String, MyShape>> entrySet = temperShapes.entrySet();
            Iterator<Map.Entry<String, MyShape>> itr = entrySet.iterator();
            while (itr.hasNext()) {
                Map.Entry<String, MyShape> entry = itr.next();
                String ownerName = entry.getKey();
                Shape shape = entry.getValue().getShape();
                g2.setPaint(entry.getValue().getColor());
                if(entry.getValue().getIsFill()==true) {
                    g2.fill(shape);
                }else {
                    g2.draw(shape);
                }
            }

            if (inputStringBound!=null) {
                g2.setStroke(new BasicStroke(2));
                g2.setPaint(Color.black);
                g2.draw(inputStringBound);
            }

        }

        private MyShape createNewShape() {
            Shape r = null;
            boolean b=false;
            float bs=2;
            switch (s) {
                case "Rectangle":
                    r = makeRectangle(startDrag.x, startDrag.y, endDrag.x, endDrag.y);
                    break;
                case "RectangleF":
                    b = true;
                    r = makeRectangle(startDrag.x, startDrag.y, endDrag.x, endDrag.y);
                    break;
                case "Oval":
                    r = makeEllipse(startDrag.x, startDrag.y, endDrag.x, endDrag.y);
                    break;
                case "OvalF":
                    b = true;
                    r = makeEllipse(startDrag.x, startDrag.y, endDrag.x, endDrag.y);
                    break;
                case "Circle":
                    r = makeCircle(startDrag.x, startDrag.y, endDrag.x, endDrag.y);
                    break;
                case "CircleF":
                    b = true;
                    r = makeCircle(startDrag.x, startDrag.y, endDrag.x, endDrag.y);
                    break;
                case "Line":
                    r = makeLine(startDrag.x, startDrag.y, endDrag.x, endDrag.y);
                    break;
                case "Painting Brush":
                    bs=10;
                    r = (Shape) path.clone();
                    break;
                case "Draw Pen":
                    r = (Shape) path.clone();
                    break;
                case "EraserS":
                    c = Color.white;
                    bs=6;
                    r = (Shape) path.clone();
                    break;
                case "EraserM":
                    c = Color.white;
                    bs=12;
                    r = (Shape) path.clone();
                    break;
                case "EraserL":
                    c = Color.white;
                    bs=18;
                    r = (Shape) path.clone();
                    break;
                case "Text":
                    r = (Shape) path.clone();
                    break;
                default:
                    System.out.print(s);
                    System.out.printf("In PaintSurface.createNewShape: unknown currentState [%s]\n", s);
                    break;
            }
            return new MyShape(r,c,b,bs);
        }

        public void addTemperShape(String ownerName, MyShape s) {
            temperShapes.put(ownerName, s);
            addShapeToRWB(ownerName, s, false);
        }

        public void addDurableShape(String ownerName, MyShape s) {
            temperShapes.remove(ownerName);
            shapes.add(s);
            addShapeToRWB(ownerName, s, true);
        }

        public void addShapeToRWB(String ownerName, MyShape s, boolean isDurable) {
            if (isCenter) {
                Set<Map.Entry<String, IRemoteWhiteBoard>> entrySet = rWhiteBoards.entrySet();
                Iterator<Map.Entry<String, IRemoteWhiteBoard>> itr = entrySet.iterator();
                while (itr.hasNext()) {
                    Map.Entry<String, IRemoteWhiteBoard> entry = itr.next();
                    String rOwnerName = entry.getKey();
                    IRemoteWhiteBoard rwb = entry.getValue();
                    if (!rOwnerName.equals(ownerName)) {
                        try {
                            if (isDurable) {
                                rwb.painted(ownerName, s);
                            }
                            else {
                                rwb.painting(ownerName, s);
                            }
                        } catch (RemoteException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
            else {
                try {
                    if (isDurable) {
                        centerWhiteBoard.painted(ownerName, s);
                    }
                    else {
                        centerWhiteBoard.painting(ownerName, s);
                    }
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }

        private Rectangle2D.Float makeRectangle(int x1, int y1, int x2, int y2) {
            return new Rectangle2D.Float(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x1 - x2), Math.abs(y1 - y2));
        }

        private Ellipse2D.Float makeEllipse(int x1, int y1, int x2, int y2) {
            return new Ellipse2D.Float(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x1 - x2), Math.abs(y1 - y2));
        }

        private Line2D.Float makeLine(int x1, int y1, int x2, int y2){
            return new Line2D.Float(x1, y1, x2,y2);
        }

        private Ellipse2D.Float makeCircle(int x1, int y1, int x2, int y2) {
            if(Math.abs(x1 - x2)>Math.abs(y1 - y2)) {
                return new Ellipse2D.Float(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x1 - x2), Math.abs(x1 - x2));
            }else {
                return new Ellipse2D.Float(Math.min(x1, x2), Math.min(y1, y2), Math.abs(y1 - y2), Math.abs(y1 - y2));
            }
        }

        private Shape makeTextLayout() {
            Graphics2D g2d = (Graphics2D)paintSurface.getGraphics();

            FontRenderContext frc = g2d.getFontRenderContext();
            AffineTransform transform = new AffineTransform();
            transform.setToTranslation(inputPosition.getX(), inputPosition.getY()+10);
            TextLayout tl = new TextLayout(inputString, new Font("Monaco", Font.PLAIN, 18), frc);
            return tl.getOutline(transform);
        }

        public void setShapes(CopyOnWriteArrayList<MyShape> shapes) {
            this.shapes = shapes;
        }
        public void setFileName(String fileName){
            this.fileName=fileName;
        }

    }
    public void save() {
        save.setVisible(true);
        save.setBounds(300,300,400,400);
        JPanel savePanel=new JPanel();
        save.add(savePanel);
        savePanel.setOpaque(false);
        savePanel.setLayout(null);
        JLabel w=new JLabel("Are you sure to save?");
        w.setBounds(100,50,150,50);
        fileNameText=new JTextField(paintSurface.fileName);
        fileNameText.setBounds(100,150,150,50);
        JButton confirm = new JButton("confirm");
        confirm.setActionCommand("confirm");
        confirm.addActionListener(new RemoteWhiteBoard.buttonListener());
        confirm.setBounds(160, 250, 70, 50);
        savePanel.add(confirm);
        savePanel.add(w);
        savePanel.add(fileNameText);
        savePanel.setVisible(true);
        save.setVisible(true);
    }
    public void saveFile(String filePath,CopyOnWriteArrayList<MyShape> theShape){
        try {
            ObjectOutputStream outputStream = new ObjectOutputStream
                    (new FileOutputStream(filePath));
            outputStream.writeObject(theShape);
            outputStream.close();
            saveSuccessful();
        } catch (IOException E) {
            System.out.println("Error opening the file.");
            saveFailed();
        }
    }
    public void open() {
        open=new JFrame("open");
        open.setVisible(true);
        JFileChooser jfc = new JFileChooser();
        open.add(jfc);
        open.addWindowListener(new myWindowListener());
        String[] filterString = {".rwb"};
        MyFilter filter = new MyFilter(filterString);
        String jarFilePath = RemoteWhiteBoard.class.getProtectionDomain().getCodeSource().getLocation().getFile();
        jfc.setCurrentDirectory(new File(jarFilePath));
        jfc.setFileFilter(filter);
        int state=jfc.showOpenDialog(null);
        if(state!=JFileChooser.APPROVE_OPTION){
            open.setVisible(false);
        }
        else{
            File fl = jfc.getSelectedFile();
            String filePath=fl.getAbsolutePath();
            String fileNn=fl.getName();
            CopyOnWriteArrayList<MyShape> theShape = new CopyOnWriteArrayList<>();
            try {
                ObjectInputStream inputStream = new ObjectInputStream
                        (new FileInputStream(filePath));
                theShape = (CopyOnWriteArrayList<MyShape>) inputStream.readObject();
                inputStream.close();
            } catch (ClassNotFoundException e) {
                System.out.println("Problems with file input1.");
            } catch (IOException e) {
                System.out.println("Problems with file input2.");
            }
            paintSurface.setShapes(theShape);
            paintSurface.repaint();
            paintSurface.setFileName(fileNn.substring(0, fileNn.length() - 4));
        }
        }
    public void saveas() { ;
        saveas.setVisible(true);
        JFileChooser jfc = new JFileChooser();
        saveas.add(jfc);
        saveas.addWindowListener(new myWindowListener());
        String jarFilePath = RemoteWhiteBoard.class.getProtectionDomain().getCodeSource().getLocation().getFile();
        try {
            jarFilePath = URLDecoder.decode(jarFilePath, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        jfc.setCurrentDirectory(new File(jarFilePath));
        int state=jfc.showSaveDialog(null);
        if(state!=JFileChooser.APPROVE_OPTION){
            saveas.setVisible(false);
        }
        else{
            File fl = jfc.getSelectedFile();
            String filepath=jfc.getCurrentDirectory()+"/"+fl.getName()+".rwb";
            CopyOnWriteArrayList<MyShape> theShape = paintSurface.shapes;
            saveFile(filepath,theShape);
        }
    }
    
    public void saveSuccessful(){
        save.setVisible(false);
        saveas.setVisible(false);
        saveSuccessfulOrNot=new JFrame("successful");
        saveSuccessfulOrNot.setVisible(true);
        saveSuccessfulOrNot.setBounds(300,300,350,220);
        JPanel sPanal=new JPanel();
        sPanal.setOpaque(false);
        sPanal.setLayout(null);
        saveSuccessfulOrNot.add(sPanal);
        JLabel saveSuccessful=new JLabel("Save the file Successful!");
        saveSuccessful.setBounds(80,50,200,50);
        JButton close=new JButton("close");
        close.setActionCommand("close");
        close.setBounds(159,150,80,50);
        close.addActionListener(new RemoteWhiteBoard.buttonListener());
        sPanal.add(saveSuccessful);
        sPanal.add(close);
    }
    public void saveFailed(){
        saveSuccessfulOrNot=new JFrame("faild");
        saveSuccessfulOrNot.setVisible(true);
        saveSuccessfulOrNot.setBounds(300,300,350,220);
        JPanel sPanal=new JPanel();
        sPanal.setOpaque(false);
        sPanal.setLayout(null);
        saveSuccessfulOrNot.add(sPanal);
        JLabel saveSuccessful=new JLabel("Save the file falid!");
        saveSuccessful.setBounds(80,50,200,50);
        JButton close=new JButton("close");
        close.setActionCommand("close");
        close.setBounds(159,150,80,50);
        close.addActionListener(new RemoteWhiteBoard.buttonListener());
        sPanal.add(saveSuccessful);
        sPanal.add(close);
    }
    public class buttonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            if(command.equals("confirm")){
                CopyOnWriteArrayList<MyShape> theShape = paintSurface.shapes;
                paintSurface.setFileName(fileNameText.getText());
                System.out.println(paintSurface.fileName+".rwb");
                saveFile(paintSurface.fileName+".rwb",theShape);
            }
            else if(command.equals("close")){
                saveSuccessfulOrNot.setVisible(false);
            }
        }
    }
    static class myWindowListener extends WindowAdapter {
        @Override
        public void windowClosing(WindowEvent e){
            super.windowClosing(e);
        }
    }
}
